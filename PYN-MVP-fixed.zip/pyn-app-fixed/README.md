# PYN MVP

PYN is a social Python-learning prototype inspired by the browseable community feeling of Roblox and the progression/customization ideas found in learning apps.

## What is included

- Mock sign-in / create profile screen
- Home dashboard
- Active/offline learner avatars
- XP and streak display
- 30 Python beginner lessons with examples and mini challenges
- Project browser with Beginner, Intermediate, and Advanced filters
- Project completion and XP rewards
- Community feed prototype
- Avatar customization
- Profile editing
- Local progress persistence using localStorage
- Responsive desktop/mobile layout

## Run it

No installation is required.

1. Open `index.html` directly in a browser, or
2. From this folder run a simple local server, for example:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Important

This is a front-end MVP. It does not yet have a real backend, database, authentication system, chat, moderation, or code-execution sandbox. Those should be added before publishing PYN publicly.
